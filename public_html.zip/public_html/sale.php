   
<?php include "header.php"; ?>
<p>sale items</p>

<?php include "footer.php"; ?>

