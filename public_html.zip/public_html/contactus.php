
<?php
	echo 'Phone Number: 1-800-gli-glos';
	echo 'Fax: 1-800-1ma-keup';
	echo 'Address: 128 First Avenue <br>
			New York City, NY 15422';
?>