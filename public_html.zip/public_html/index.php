<?php include "header.php"; ?>

<h1>Welcome to Glitter 'n gloss!</h1>
<div class="logo">
    <img src="makeUp.jpg" width="1000"; height="500";>
</div>

<?php include "footer.php"; ?>




