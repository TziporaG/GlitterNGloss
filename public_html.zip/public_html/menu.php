<div class="topnav">
  <a class="active" href="index.php">Home</a>
  <a href="face.php">Face</a>
  <a href="eye.php">Eye</a>
  <a href="lip.php">Lip</a>
  <a href="brushes.php">Brushes</a>
   <a href="sale.php">Sale</a>
   <a href="about.php">About Us</a>
 <a href="locations.php">Locations</a>  
   <a href="consultations.php">Consultations</a>
    <a href="reviews.php">Reviews</a>
    <a href="loginToCart.php">Cart</a>
</div>