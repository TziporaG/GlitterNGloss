
<?php include "header.php"; ?>

<p>this will have lip products</p>
<?php include "footer.php"; ?>

