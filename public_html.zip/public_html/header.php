<HTML>
    <HEAD>
        <title>Glitter 'n Gloss</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <LINK rel="stylesheet" href="StyleSheet_FinalProject.css" type="text/css" />
    </HEAD>
    <BODY class = "body">
        <div class="logo">
            <img src="logo2.png" width="150"; height="150";>
        </div>
        <?php include "menu.php"; ?>
        <HR />

