

<?php include "header.php"; ?>
<p>about glitter 'n gloss</p>

<?php include "footer.php"; ?>
